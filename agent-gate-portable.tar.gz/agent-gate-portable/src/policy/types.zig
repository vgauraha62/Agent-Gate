//! Policy types - Core data structures for policy evaluation.
//!
//! Defines the core types: Effect, Method, Condition, Policy, and RequestContext.

const std = @import("std");

/// Effect - The result of policy evaluation.
pub const Effect = enum(u1) {
    /// Deny the request.
    deny = 0,
    /// Allow the request.
    allow = 1,

    const Self = @This();

    /// Parse effect from string.
    pub fn parse(s: []const u8) !Self {
        if (std.mem.eql(u8, s, "allow")) return .allow;
        if (std.mem.eql(u8, s, "deny")) return .deny;
        return error.InvalidEffect;
    }
};

/// Decision - The result of policy evaluation with attribution.
/// Day 6: Extended from Effect to include policy_id for audit logging.
pub const Decision = struct {
    /// The effect of the decision.
    effect: Effect,
    /// The ID of the policy that produced this decision.
    policy_id: []const u8,
    /// Timestamp of evaluation (Unix nanoseconds).
    timestamp: i128,
    /// Time taken for evaluation in nanoseconds.
    evaluation_time_ns: u64,

    const Self = @This();

    /// Create an allow decision with a specific policy ID.
    pub fn allow(policy_id: []const u8, eval_time_ns: u64) Self {
        return Self{
            .effect = .allow,
            .policy_id = policy_id,
            .timestamp = std.time.timestamp(),
            .evaluation_time_ns = eval_time_ns,
        };
    }

    /// Create a deny decision with a specific policy ID.
    pub fn deny(policy_id: []const u8, eval_time_ns: u64) Self {
        return Self{
            .effect = .deny,
            .policy_id = policy_id,
            .timestamp = std.time.timestamp(),
            .evaluation_time_ns = eval_time_ns,
        };
    }

    /// Create a default deny decision (no matching policy).
    pub fn defaultDeny() Self {
        return Self{
            .effect = .deny,
            .policy_id = "default-deny",
            .timestamp = std.time.timestamp(),
            .evaluation_time_ns = 0,
        };
    }
};

/// HTTP Methods supported by policies.
pub const Method = enum(u3) {
    GET = 0,
    POST = 1,
    PUT = 2,
    DELETE = 3,
    PATCH = 4,
    OPTIONS = 5,
    HEAD = 6,

    const Self = @This();

    /// Parse method from string (case-insensitive).
    pub fn parse(s: []const u8) !Self {
        // Uppercase copy and compare
        var buf: [10]u8 = undefined;
        const upper = if (s.len <= buf.len) upper: {
            for (s, 0..) |c, i| {
                if (c >= 'a' and c <= 'z') {
                    buf[i] = c - 32;
                } else {
                    buf[i] = c;
                }
            }
            break :upper buf[0..s.len];
        } else s;

        if (std.mem.eql(u8, upper, "GET")) return .GET;
        if (std.mem.eql(u8, upper, "POST")) return .POST;
        if (std.mem.eql(u8, upper, "PUT")) return .PUT;
        if (std.mem.eql(u8, upper, "DELETE")) return .DELETE;
        if (std.mem.eql(u8, upper, "PATCH")) return .PATCH;
        if (std.mem.eql(u8, upper, "OPTIONS")) return .OPTIONS;
        if (std.mem.eql(u8, upper, "HEAD")) return .HEAD;
        return error.InvalidMethod;
    }

    /// Get string representation.
    pub fn string(self: Self) []const u8 {
        return switch (self) {
            .GET => "GET",
            .POST => "POST",
            .PUT => "PUT",
            .DELETE => "DELETE",
            .PATCH => "PATCH",
            .OPTIONS => "OPTIONS",
            .HEAD => "HEAD",
        };
    }
};

/// Condition - A single matching condition for a policy.
/// Conditions are AND'd together within a policy.
pub const Condition = union(enum) {
    /// Match against agent_id (supports "*" wildcard).
    agent_id: []const u8,
    /// Match against request path (supports prefix wildcard like "/api/*").
    path: []const u8,
    /// Match against a single HTTP method.
    method: Method,
    /// Match against multiple HTTP methods (any match).
    methods: []const Method,
    /// Sleep for specified milliseconds then match (for timeout testing).
    slow_match: u64,

    // === AI Agent Tool Conditions ===

    /// Match on tool name (e.g., "bash", "read_file", "edit").
    /// Exact match against the tool_name in RequestContext.
    tool: []const u8,
    /// Match on tool name with wildcard suffix (e.g., "read_*" matches "read_file", "read").
    /// Supports "*" for any tool and "prefix_*" for prefix matching.
    tool_pattern: []const u8,
    /// Substring/regex match on command content (e.g., "rm -rf", "cat .env").
    /// If the pattern appears anywhere in the command string, the condition matches.
    command_pattern: []const u8,
    /// Prefix/substring match on file path accessed by tool (e.g., "/workspace/*").
    /// Supports "*" wildcard, "prefix/*" prefix matching, and exact/substring matching.
    path_pattern: []const u8,

    const Self = @This();

    /// Check if this condition matches the request context.
    pub fn matches(self: Self, ctx: *const RequestContext) bool {
        return switch (self) {
            .agent_id => matchesAgentId(self.agent_id, ctx.agent_id),
            .path => matchesPath(self.path, ctx.path),
            .method => self.method == ctx.method,
            .methods => matchesMethodAny(self.methods, ctx.method),
            .slow_match => |ms| {
                std.Thread.sleep(ms * std.time.ns_per_ms);
                return true;
            },
            // Tool conditions
            .tool => matchesToolName(self.tool, ctx.tool_name),
            .tool_pattern => matchesToolPattern(self.tool_pattern, ctx.tool_name),
            .command_pattern => matchesCommandPattern(self.command_pattern, ctx.tool_command),
            .path_pattern => matchesPathPattern(self.path_pattern, ctx.tool_path),
        };
    }
};

/// Policy - A single policy rule with effect and conditions.
pub const Policy = struct {
    /// Unique identifier for the policy.
    id: []const u8,
    /// Effect when this policy matches.
    effect: Effect,
    /// Conditions to match (AND'd together).
    conditions: []const Condition,

    const Self = @This();

    /// Check if all conditions match the request context.
    pub fn matchesAll(self: *const Self, ctx: *const RequestContext) bool {
        for (self.conditions) |cond| {
            if (!cond.matches(ctx)) return false;
        }
        return true;
    }
};

/// RequestContext - The context for policy evaluation.
/// Contains information about the incoming request.
pub const RequestContext = struct {
    /// Agent ID from JWT token (sub claim).
    agent_id: []const u8,
    /// Request path.
    path: []const u8,
    /// HTTP method.
    method: Method,

    // === AI Agent Tool Fields ===
    /// Tool name being invoked (e.g., "bash", "read_file", "edit").
    tool_name: []const u8,
    /// Command string or content passed to the tool.
    tool_command: []const u8,
    /// File path being accessed by the tool.
    tool_path: []const u8,

    const Self = @This();

    /// Create a new request context (standard HTTP policy evaluation).
    pub fn init(agent_id: []const u8, path: []const u8, method: Method) Self {
        return Self{
            .agent_id = agent_id,
            .path = path,
            .method = method,
            .tool_name = "",
            .tool_command = "",
            .tool_path = "",
        };
    }

    /// Create a new request context for AI agent tool evaluation.
    /// The `path` field is set to `tool_path` if non-empty, otherwise `tool`.
    pub fn initTool(agent_id: []const u8, tool: []const u8, command: []const u8, path: []const u8) Self {
        return Self{
            .agent_id = agent_id,
            .path = if (path.len > 0) path else tool,
            .method = .POST,
            .tool_name = tool,
            .tool_command = command,
            .tool_path = path,
        };
    }
};

/// PolicySet - A collection of policies for evaluation.
/// Uses first-match-wins strategy.
pub const PolicySet = struct {
    /// List of policies to evaluate in order.
    policies: []const Policy,

    const Self = @This();

    /// Evaluate the request context against all policies.
    /// Returns first matching policy's effect, or deny if none match.
    pub fn evaluate(self: *const Self, ctx: *const RequestContext) Effect {
        for (self.policies) |policy| {
            if (policy.matchesAll(ctx)) {
                return policy.effect;
            }
        }
        return .deny; // Default deny
    }

    /// Evaluate the request context and return a Decision with policy attribution.
    /// Day 6: Extended version for audit logging.
    pub fn evaluateWithDecision(self: *const Self, ctx: *const RequestContext) Decision {
        const start_time = std.time.nanoTimestamp();

        for (self.policies) |policy| {
            if (policy.matchesAll(ctx)) {
                const eval_time = @as(u64, @intCast(std.time.nanoTimestamp() - start_time));
                // Return the policy's actual effect (allow or deny)
                switch (policy.effect) {
                    .allow => return Decision.allow(policy.id, eval_time),
                    .deny => return Decision.deny(policy.id, eval_time),
                }
            }
        }

        // Default deny when no policy matches
        const eval_time = @as(u64, @intCast(std.time.nanoTimestamp() - start_time));
        return Decision{
            .effect = .deny,
            .policy_id = "default-deny",
            .timestamp = std.time.timestamp(),
            .evaluation_time_ns = eval_time,
        };
    }

    /// Evaluate the request context with a timeout.
    /// Returns error.PolicyTimeout if evaluation exceeds timeout_ms.
    /// Checks timeout both before and after matchesAll() to catch slow_match delays.
    pub fn evaluateWithTimeout(self: *const Self, ctx: *const RequestContext, timeout_ms: u32) !Decision {
        const start_time = std.time.nanoTimestamp();
        const timeout_ns: i64 = @as(i64, timeout_ms) * std.time.ns_per_ms;

        for (self.policies) |policy| {
            // Check timeout BEFORE evaluation
            if (std.time.nanoTimestamp() - start_time >= timeout_ns) return error.PolicyTimeout;

            if (policy.matchesAll(ctx)) {
                // Check timeout AFTER evaluation (catches slow_match delay)
                if (std.time.nanoTimestamp() - start_time >= timeout_ns) return error.PolicyTimeout;

                const eval_time = @as(u64, @intCast(std.time.nanoTimestamp() - start_time));
                switch (policy.effect) {
                    .allow => return Decision.allow(policy.id, eval_time),
                    .deny => return Decision.deny(policy.id, eval_time),
                }
            }
        }

        const eval_time = @as(u64, @intCast(std.time.nanoTimestamp() - start_time));
        return Decision.deny("default-deny", eval_time);
    }
};

/// PolicyError - Errors for policy operations.
pub const PolicyError = error{
    InvalidEffect,
    InvalidMethod,
    InvalidPolicy,
    InvalidCondition,
    ParseError,
    PolicyTimeout,
};

/// Match agent_id against pattern (supports "*" wildcard).
fn matchesAgentId(pattern: []const u8, agent_id: []const u8) bool {
    if (std.mem.eql(u8, pattern, "*")) return true;
    return std.mem.eql(u8, pattern, agent_id);
}

/// Match path against pattern (supports prefix wildcard "/api/*").
fn matchesPath(pattern: []const u8, path: []const u8) bool {
    if (std.mem.eql(u8, pattern, "*")) return true;

    // Check for prefix wildcard (ends with "/*")
    if (pattern.len >= 2 and pattern[pattern.len - 2] == '/' and pattern[pattern.len - 1] == '*') {
        const prefix = pattern[0 .. pattern.len - 2];
        return std.mem.startsWith(u8, path, prefix);
    }

    return std.mem.eql(u8, pattern, path);
}

/// Match if method is in the list.
fn matchesMethodAny(methods: []const Method, method: Method) bool {
    for (methods) |m| {
        if (m == method) return true;
    }
    return false;
}

// ============================================================================
// AI Agent Tool Matching Functions
// ============================================================================

/// Match tool name exactly against the pattern.
fn matchesToolName(pattern: []const u8, tool_name: []const u8) bool {
    if (std.mem.eql(u8, pattern, "*")) return true;
    return std.mem.eql(u8, pattern, tool_name);
}

/// Match tool name with wildcard support.
/// Supports exact match, "*" (any tool), and "prefix_*" (prefix match).
fn matchesToolPattern(pattern: []const u8, tool_name: []const u8) bool {
    if (std.mem.eql(u8, pattern, "*")) return true;
    // Check for suffix wildcard (e.g., "read_*" matches "read_file", "read")
    if (pattern.len >= 2 and pattern[pattern.len - 1] == '*') {
        const prefix = pattern[0 .. pattern.len - 1];
        // If prefix ends with '_', match tools starting with prefix
        return std.mem.startsWith(u8, tool_name, prefix);
    }
    return std.mem.eql(u8, pattern, tool_name);
}

/// Match command content against a substring pattern.
/// Returns true if the pattern appears anywhere in the command string.
fn matchesCommandPattern(pattern: []const u8, command: []const u8) bool {
    if (pattern.len == 0) return true;
    if (std.mem.eql(u8, pattern, "*")) return true;
    // Simple substring match (can be extended to regex later)
    return std.mem.indexOf(u8, command, pattern) != null;
}

/// Match file path against a pattern.
/// Supports "*" (any path), "/prefix/*" (prefix match), exact match, and substring match.
fn matchesPathPattern(pattern: []const u8, path: []const u8) bool {
    if (pattern.len == 0) return true;
    if (std.mem.eql(u8, pattern, "*")) return true;
    // Check for "/workspace/*" style prefix wildcard
    if (pattern.len >= 2 and pattern[pattern.len - 2] == '/' and pattern[pattern.len - 1] == '*') {
        const prefix = pattern[0 .. pattern.len - 2];
        return std.mem.startsWith(u8, path, prefix);
    }
    // If pattern ends with '*' (but not "/*"), use prefix match
    if (pattern.len >= 2 and pattern[pattern.len - 1] == '*') {
        const prefix = pattern[0 .. pattern.len - 1];
        return std.mem.startsWith(u8, path, prefix);
    }
    // Exact match or substring match
    return std.mem.eql(u8, pattern, path) or std.mem.indexOf(u8, path, pattern) != null;
}

// Tests

test "Effect parse valid" {
    try std.testing.expectEqual(Effect.allow, try Effect.parse("allow"));
    try std.testing.expectEqual(Effect.deny, try Effect.parse("deny"));
}

test "Effect parse invalid" {
    try std.testing.expectError(error.InvalidEffect, Effect.parse("invalid"));
}

test "Method parse valid" {
    try std.testing.expectEqual(Method.GET, try Method.parse("GET"));
    try std.testing.expectEqual(Method.POST, try Method.parse("POST"));
    try std.testing.expectEqual(Method.DELETE, try Method.parse("DELETE"));
}

test "Method parse case insensitive" {
    try std.testing.expectEqual(Method.GET, try Method.parse("get"));
    try std.testing.expectEqual(Method.POST, try Method.parse("post"));
}

test "Method parse invalid" {
    try std.testing.expectError(error.InvalidMethod, Method.parse("INVALID"));
}

test "Method string" {
    try std.testing.expectEqualStrings("GET", Method.GET.string());
    try std.testing.expectEqualStrings("POST", Method.POST.string());
}

test "Condition agent_id wildcard" {
    const ctx = RequestContext.init("any-agent", "/api/test", .GET);

    try std.testing.expect((Condition{ .agent_id = "*" }).matches(&ctx));
    try std.testing.expect((Condition{ .agent_id = "any-agent" }).matches(&ctx));
    try std.testing.expect(!(Condition{ .agent_id = "other-agent" }).matches(&ctx));
}

test "Condition path wildcard prefix" {
    const ctx = RequestContext.init("agent-1", "/api/users/123", .GET);

    try std.testing.expect((Condition{ .path = "*" }).matches(&ctx));
    try std.testing.expect((Condition{ .path = "/api/users/*" }).matches(&ctx));
    try std.testing.expect((Condition{ .path = "/api/*" }).matches(&ctx));
    try std.testing.expect(!(Condition{ .path = "/api/admin/*" }).matches(&ctx));
    try std.testing.expect((Condition{ .path = "/api/users/123" }).matches(&ctx));
}

test "Condition method" {
    const ctx = RequestContext.init("agent-1", "/api/test", .GET);

    try std.testing.expect((Condition{ .method = .GET }).matches(&ctx));
    try std.testing.expect(!(Condition{ .method = .POST }).matches(&ctx));
}

test "Condition methods array" {
    const ctx = RequestContext.init("agent-1", "/api/test", .POST);

    const methods = &[_]Method{ .GET, .POST, .PUT };
    try std.testing.expect((Condition{ .methods = methods }).matches(&ctx));
}

test "Policy matches all" {
    const conditions = &[_]Condition{
        Condition{ .agent_id = "service-a" },
        Condition{ .path = "/api/*" },
        Condition{ .method = .GET },
    };
    const policy = Policy{
        .id = "test-policy",
        .effect = .allow,
        .conditions = conditions,
    };

    const ctx = RequestContext.init("service-a", "/api/users", .GET);
    try std.testing.expect(policy.matchesAll(&ctx));

    // Missing path condition
    const ctx2 = RequestContext.init("service-a", "/other", .GET);
    try std.testing.expect(!policy.matchesAll(&ctx2));
}

test "PolicySet first match wins" {
    const deny_policy = Policy{
        .id = "deny-all",
        .effect = .deny,
        .conditions = &[_]Condition{Condition{ .path = "*" }},
    };
    const allow_policy = Policy{
        .id = "allow-api",
        .effect = .allow,
        .conditions = &[_]Condition{Condition{ .path = "/api/*" }},
    };

    const policies = &[_]Policy{ deny_policy, allow_policy };
    const set = PolicySet{ .policies = policies };

    // First policy (deny-all) matches first
    const ctx = RequestContext.init("agent", "/api/test", .GET);
    try std.testing.expectEqual(Effect.deny, set.evaluate(&ctx));
}

test "PolicySet default deny" {
    const allow_policy = Policy{
        .id = "allow-specific",
        .effect = .allow,
        .conditions = &[_]Condition{Condition{ .path = "/special/*" }},
    };

    const policies = &[_]Policy{allow_policy};
    const set = PolicySet{ .policies = policies };

    const ctx = RequestContext.init("agent", "/other", .GET);
    try std.testing.expectEqual(Effect.deny, set.evaluate(&ctx));
}

test "RequestContext init" {
    const ctx = RequestContext.init("my-agent", "/api/users", .POST);

    try std.testing.expectEqualStrings("my-agent", ctx.agent_id);
    try std.testing.expectEqualStrings("/api/users", ctx.path);
    try std.testing.expectEqual(Method.POST, ctx.method);
}

// Edge case tests

test "Effect case sensitivity" {
    // Effect parsing is case-sensitive
    try std.testing.expectError(error.InvalidEffect, Effect.parse("ALLOW"));
    try std.testing.expectError(error.InvalidEffect, Effect.parse("Deny"));
    try std.testing.expectError(error.InvalidEffect, Effect.parse(""));
}

test "Effect empty string" {
    try std.testing.expectError(error.InvalidEffect, Effect.parse(""));
}

test "Method empty string" {
    try std.testing.expectError(error.InvalidMethod, Method.parse(""));
}

test "Method special characters" {
    try std.testing.expectError(error.InvalidMethod, Method.parse("GET "));
    try std.testing.expectError(error.InvalidMethod, Method.parse(" GET"));
    try std.testing.expectError(error.InvalidMethod, Method.parse("G-ET"));
}

test "Method all valid methods" {
    try std.testing.expectEqual(Method.GET, try Method.parse("GET"));
    try std.testing.expectEqual(Method.POST, try Method.parse("POST"));
    try std.testing.expectEqual(Method.PUT, try Method.parse("PUT"));
    try std.testing.expectEqual(Method.DELETE, try Method.parse("DELETE"));
    try std.testing.expectEqual(Method.PATCH, try Method.parse("PATCH"));
    try std.testing.expectEqual(Method.OPTIONS, try Method.parse("OPTIONS"));
    try std.testing.expectEqual(Method.HEAD, try Method.parse("HEAD"));
}

test "Method mixed case" {
    try std.testing.expectEqual(Method.GET, try Method.parse("get"));
    try std.testing.expectEqual(Method.GET, try Method.parse("Get"));
    try std.testing.expectEqual(Method.GET, try Method.parse("gEt"));
}

test "Condition agent_id exact match" {
    const ctx = RequestContext.init("exact-agent", "/api/test", .GET);

    try std.testing.expect((Condition{ .agent_id = "exact-agent" }).matches(&ctx));
    try std.testing.expect(!(Condition{ .agent_id = "other-agent" }).matches(&ctx));
    try std.testing.expect(!(Condition{ .agent_id = "exact" }).matches(&ctx));
    try std.testing.expect(!(Condition{ .agent_id = "exact-agent-id" }).matches(&ctx));
}

test "Condition agent_id empty" {
    const ctx = RequestContext.init("", "/api/test", .GET);

    try std.testing.expect((Condition{ .agent_id = "*" }).matches(&ctx));
    try std.testing.expect((Condition{ .agent_id = "" }).matches(&ctx));
}

test "Condition path exact match only" {
    const ctx = RequestContext.init("agent", "/metrics", .GET);

    try std.testing.expect((Condition{ .path = "/metrics" }).matches(&ctx));
    try std.testing.expect(!(Condition{ .path = "/metrics/" }).matches(&ctx));
    try std.testing.expect(!(Condition{ .path = "/metrics/cpu" }).matches(&ctx));
    try std.testing.expect(!(Condition{ .path = "/health" }).matches(&ctx));
}

test "Condition path prefix wildcard edge cases" {
    const ctx = RequestContext.init("agent", "/api/users/123/profile", .GET);

    // Prefix wildcards
    try std.testing.expect((Condition{ .path = "/api/*" }).matches(&ctx));
    try std.testing.expect((Condition{ .path = "/api/users/*" }).matches(&ctx));
    try std.testing.expect((Condition{ .path = "/api/users/123/*" }).matches(&ctx));

    // Non-matching prefixes
    try std.testing.expect(!(Condition{ .path = "/api/admin/*" }).matches(&ctx));
    try std.testing.expect(!(Condition{ .path = "/other/*" }).matches(&ctx));

    // Missing wildcard - exact match only
    try std.testing.expect(!(Condition{ .path = "/api/users" }).matches(&ctx));
}

test "Condition path wildcard at end only" {
    // Wildcard only works at end, not in middle
    const ctx = RequestContext.init("agent", "/api/test", .GET);

    try std.testing.expect((Condition{ .path = "*" }).matches(&ctx));
    try std.testing.expect((Condition{ .path = "/api/*" }).matches(&ctx));

    // Pattern without wildcard - must be exact
    try std.testing.expect(!(Condition{ .path = "/api" }).matches(&ctx));
}

test "Condition path empty path" {
    const ctx = RequestContext.init("agent", "", .GET);

    try std.testing.expect((Condition{ .path = "*" }).matches(&ctx));
    try std.testing.expect((Condition{ .path = "" }).matches(&ctx));
    try std.testing.expect(!(Condition{ .path = "/api/*" }).matches(&ctx));
}

test "Condition path special characters" {
    const ctx = RequestContext.init("agent", "/api/test?query=1&foo=bar", .GET);

    try std.testing.expect((Condition{ .path = "/api/*" }).matches(&ctx));
    try std.testing.expect(!(Condition{ .path = "/api/test" }).matches(&ctx)); // Query string mismatch
}

test "Condition methods empty array" {
    const ctx = RequestContext.init("agent", "/api/test", .GET);
    const empty_methods: []const Method = &[_]Method{};

    try std.testing.expect(!(Condition{ .methods = empty_methods }).matches(&ctx));
}

test "Condition methods single element" {
    const ctx_post = RequestContext.init("agent", "/api/test", .POST);
    const ctx_get = RequestContext.init("agent", "/api/test", .GET);
    const methods = &[_]Method{.POST};

    try std.testing.expect((Condition{ .methods = methods }).matches(&ctx_post));
    try std.testing.expect(!(Condition{ .methods = methods }).matches(&ctx_get));
}

test "Policy empty conditions" {
    const policy = Policy{
        .id = "empty-conditions",
        .effect = .allow,
        .conditions = &[_]Condition{},
    };

    const ctx = RequestContext.init("agent", "/api/test", .GET);

    // Empty conditions = all conditions satisfied (vacuous truth)
    try std.testing.expect(policy.matchesAll(&ctx));
}

test "Policy single condition" {
    const policy = Policy{
        .id = "single-condition",
        .effect = .allow,
        .conditions = &[_]Condition{Condition{ .path = "/api/*" }},
    };

    const ctx_match = RequestContext.init("agent", "/api/test", .GET);
    const ctx_no_match = RequestContext.init("agent", "/other", .GET);

    try std.testing.expect(policy.matchesAll(&ctx_match));
    try std.testing.expect(!policy.matchesAll(&ctx_no_match));
}

test "Policy all conditions must match" {
    const policy = Policy{
        .id = "multi-condition",
        .effect = .allow,
        .conditions = &[_]Condition{
            Condition{ .agent_id = "service-a" },
            Condition{ .path = "/api/*" },
            Condition{ .method = .GET },
        },
    };

    // All match
    const ctx_all = RequestContext.init("service-a", "/api/test", .GET);
    try std.testing.expect(policy.matchesAll(&ctx_all));

    // Only agent_id matches
    const ctx_agent = RequestContext.init("service-a", "/other", .POST);
    try std.testing.expect(!policy.matchesAll(&ctx_agent));

    // Only path matches
    const ctx_path = RequestContext.init("other", "/api/test", .POST);
    try std.testing.expect(!policy.matchesAll(&ctx_path));

    // Only method matches
    const ctx_method = RequestContext.init("other", "/other", .GET);
    try std.testing.expect(!policy.matchesAll(&ctx_method));
}

test "PolicySet empty policies" {
    const policies = &[_]Policy{};
    const set = PolicySet{ .policies = policies };

    const ctx = RequestContext.init("agent", "/api/test", .GET);
    try std.testing.expectEqual(Effect.deny, set.evaluate(&ctx));
}

test "PolicySet single allow policy" {
    const policies = &[_]Policy{
        Policy{
            .id = "allow-all",
            .effect = .allow,
            .conditions = &[_]Condition{Condition{ .path = "*" }},
        },
    };
    const set = PolicySet{ .policies = policies };

    const ctx = RequestContext.init("agent", "/any/path", .GET);
    try std.testing.expectEqual(Effect.allow, set.evaluate(&ctx));
}

test "PolicySet single deny policy" {
    const policies = &[_]Policy{
        Policy{
            .id = "deny-all",
            .effect = .deny,
            .conditions = &[_]Condition{Condition{ .path = "*" }},
        },
    };
    const set = PolicySet{ .policies = policies };

    const ctx = RequestContext.init("agent", "/any/path", .GET);
    try std.testing.expectEqual(Effect.deny, set.evaluate(&ctx));
}

test "PolicySet ordering matters - specific before general" {
    const policies_specific_first = &[_]Policy{
        Policy{
            .id = "allow-api",
            .effect = .allow,
            .conditions = &[_]Condition{Condition{ .path = "/api/*" }},
        },
        Policy{
            .id = "deny-all",
            .effect = .deny,
            .conditions = &[_]Condition{Condition{ .path = "*" }},
        },
    };

    const policies_general_first = &[_]Policy{
        Policy{
            .id = "deny-all",
            .effect = .deny,
            .conditions = &[_]Condition{Condition{ .path = "*" }},
        },
        Policy{
            .id = "allow-api",
            .effect = .allow,
            .conditions = &[_]Condition{Condition{ .path = "/api/*" }},
        },
    };

    const ctx_api = RequestContext.init("agent", "/api/test", .GET);
    const ctx_other = RequestContext.init("agent", "/other", .GET);

    // Specific first: /api/* allowed, /other denied
    const set_specific = PolicySet{ .policies = policies_specific_first };
    try std.testing.expectEqual(Effect.allow, set_specific.evaluate(&ctx_api));
    try std.testing.expectEqual(Effect.deny, set_specific.evaluate(&ctx_other));

    // General first: everything denied (first match wins)
    const set_general = PolicySet{ .policies = policies_general_first };
    try std.testing.expectEqual(Effect.deny, set_general.evaluate(&ctx_api));
    try std.testing.expectEqual(Effect.deny, set_general.evaluate(&ctx_other));
}

test "PolicySet multiple policies with same effect" {
    const policies = &[_]Policy{
        Policy{
            .id = "allow-api",
            .effect = .allow,
            .conditions = &[_]Condition{Condition{ .path = "/api/*" }},
        },
        Policy{
            .id = "allow-admin",
            .effect = .allow,
            .conditions = &[_]Condition{Condition{ .path = "/admin/*" }},
        },
        Policy{
            .id = "allow-health",
            .effect = .allow,
            .conditions = &[_]Condition{Condition{ .path = "/health" }},
        },
    };
    const set = PolicySet{ .policies = policies };

    const ctx_api = RequestContext.init("agent", "/api/users", .GET);
    const ctx_admin = RequestContext.init("agent", "/admin/settings", .GET);
    const ctx_health = RequestContext.init("agent", "/health", .GET);
    const ctx_other = RequestContext.init("agent", "/other", .GET);

    try std.testing.expectEqual(Effect.allow, set.evaluate(&ctx_api));
    try std.testing.expectEqual(Effect.allow, set.evaluate(&ctx_admin));
    try std.testing.expectEqual(Effect.allow, set.evaluate(&ctx_health));
    try std.testing.expectEqual(Effect.deny, set.evaluate(&ctx_other));
}

test "PolicySet allow and deny mixed" {
    const policies = &[_]Policy{
        Policy{
            .id = "allow-api",
            .effect = .allow,
            .conditions = &[_]Condition{Condition{ .path = "/api/*" }},
        },
        Policy{
            .id = "deny-admin",
            .effect = .deny,
            .conditions = &[_]Condition{Condition{ .path = "/api/admin/*" }},
        },
    };
    const set = PolicySet{ .policies = policies };

    // /api/admin/* matches allow-api first (first match wins)
    const ctx_admin = RequestContext.init("agent", "/api/admin/users", .GET);
    try std.testing.expectEqual(Effect.allow, set.evaluate(&ctx_admin));
}

test "RequestContext special characters in agent_id" {
    const ctx = RequestContext.init("service-with-dash_underscore123", "/api/test", .GET);

    try std.testing.expectEqualStrings("service-with-dash_underscore123", ctx.agent_id);
}

test "RequestContext unicode in path" {
    const ctx = RequestContext.init("agent", "/api/users/用户名", .GET);

    try std.testing.expectEqualStrings("/api/users/用户名", ctx.path);
}

test "RequestContext very long path" {
    const long_path = "/api/" ++ "segment/" ** 20;
    const ctx = RequestContext.init("agent", long_path, .GET);

    try std.testing.expect((Condition{ .path = "/api/*" }).matches(&ctx));
}

test "wildcard matches everything including empty" {
    const empty_ctx = RequestContext.init("", "", .GET);
    try std.testing.expect((Condition{ .path = "*" }).matches(&empty_ctx));
    try std.testing.expect((Condition{ .agent_id = "*" }).matches(&empty_ctx));
}

test "method condition does not check path or agent_id" {
    const ctx1 = RequestContext.init("agent-a", "/path-a", .GET);
    const ctx2 = RequestContext.init("agent-b", "/path-b", .GET);

    const method_cond = Condition{ .method = .GET };
    try std.testing.expect(method_cond.matches(&ctx1));
    try std.testing.expect(method_cond.matches(&ctx2));
}

test "path condition does not check agent_id or method" {
    const ctx1 = RequestContext.init("agent-a", "/api/test", .POST);
    const ctx2 = RequestContext.init("agent-b", "/api/test", .DELETE);

    const path_cond = Condition{ .path = "/api/*" };
    try std.testing.expect(path_cond.matches(&ctx1));
    try std.testing.expect(path_cond.matches(&ctx2));
}

test "agent_id condition does not check path or method" {
    const ctx1 = RequestContext.init("specific-agent", "/path-a", .GET);
    const ctx2 = RequestContext.init("specific-agent", "/path-b", .DELETE);

    const agent_cond = Condition{ .agent_id = "specific-agent" };
    try std.testing.expect(agent_cond.matches(&ctx1));
    try std.testing.expect(agent_cond.matches(&ctx2));
}

// ============================================================================
// Decision struct tests (Day 6)
// ============================================================================

test "Decision: allow creates correct struct" {
    const decision = Decision.allow("policy-001", 1500);

    try std.testing.expectEqual(Effect.allow, decision.effect);
    try std.testing.expectEqualStrings("policy-001", decision.policy_id);
    try std.testing.expectEqual(@as(u64, 1500), decision.evaluation_time_ns);
    try std.testing.expect(decision.timestamp > 0);
}

test "Decision: deny creates correct struct" {
    const decision = Decision.deny("policy-002", 2000);

    try std.testing.expectEqual(Effect.deny, decision.effect);
    try std.testing.expectEqualStrings("policy-002", decision.policy_id);
    try std.testing.expectEqual(@as(u64, 2000), decision.evaluation_time_ns);
}

test "Decision: defaultDeny has correct defaults" {
    const decision = Decision.defaultDeny();

    try std.testing.expectEqual(Effect.deny, decision.effect);
    try std.testing.expectEqualStrings("default-deny", decision.policy_id);
    try std.testing.expectEqual(@as(u64, 0), decision.evaluation_time_ns);
}

test "Decision: timestamp is set on creation" {
    const before = std.time.timestamp();
    const decision = Decision.allow("test", 0);
    const after = std.time.timestamp();

    try std.testing.expect(decision.timestamp >= before);
    try std.testing.expect(decision.timestamp <= after);
}

test "PolicySet: evaluateWithDecision returns Decision with policy_id" {
    const policies = &[_]Policy{
        Policy{
            .id = "allow-api",
            .effect = .allow,
            .conditions = &[_]Condition{Condition{ .path = "/api/*" }},
        },
    };

    const set = PolicySet{ .policies = policies };
    const ctx = RequestContext.init("agent", "/api/test", .GET);
    const decision = set.evaluateWithDecision(&ctx);

    try std.testing.expectEqual(Effect.allow, decision.effect);
    try std.testing.expectEqualStrings("allow-api", decision.policy_id);
    try std.testing.expect(decision.evaluation_time_ns >= 0);
}

test "PolicySet: evaluateWithDecision no match returns default-deny" {
    const policies = &[_]Policy{
        Policy{
            .id = "allow-specific",
            .effect = .allow,
            .conditions = &[_]Condition{Condition{ .path = "/specific/*" }},
        },
    };

    const set = PolicySet{ .policies = policies };
    const ctx = RequestContext.init("agent", "/other", .GET);
    const decision = set.evaluateWithDecision(&ctx);

    try std.testing.expectEqual(Effect.deny, decision.effect);
    try std.testing.expectEqualStrings("default-deny", decision.policy_id);
}

test "PolicySet: evaluateWithDecision first-match-wins with policy_id" {
    const policies = &[_]Policy{
        Policy{
            .id = "deny-all",
            .effect = .deny,
            .conditions = &[_]Condition{Condition{ .path = "*" }},
        },
        Policy{
            .id = "allow-api",
            .effect = .allow,
            .conditions = &[_]Condition{Condition{ .path = "/api/*" }},
        },
    };

    const set = PolicySet{ .policies = policies };
    const ctx = RequestContext.init("agent", "/api/test", .GET);
    const decision = set.evaluateWithDecision(&ctx);

    // First match (deny-all) wins
    try std.testing.expectEqual(Effect.deny, decision.effect);
    try std.testing.expectEqualStrings("deny-all", decision.policy_id);
}

test "PolicySet: evaluateWithDecision evaluation_time_ns is measured" {
    const policies = &[_]Policy{
        Policy{
            .id = "allow-api",
            .effect = .allow,
            .conditions = &[_]Condition{Condition{ .path = "/api/*" }},
        },
    };

    const set = PolicySet{ .policies = policies };
    const ctx = RequestContext.init("agent", "/api/test", .GET);

    // Run multiple times to ensure timing is captured
    var total_time: u64 = 0;
    for (0..10) |_| {
        const decision = set.evaluateWithDecision(&ctx);
        total_time += decision.evaluation_time_ns;
    }

    // Average should be non-zero
    try std.testing.expect(total_time > 0);
}

test "PolicySet: evaluate vs evaluateWithDecision consistency" {
    const policies = &[_]Policy{
        Policy{
            .id = "allow-api",
            .effect = .allow,
            .conditions = &[_]Condition{Condition{ .path = "/api/*" }},
        },
        Policy{
            .id = "deny-admin",
            .effect = .deny,
            .conditions = &[_]Condition{Condition{ .path = "/admin/*" }},
        },
    };

    const set = PolicySet{ .policies = policies };
    const ctx_api = RequestContext.init("agent", "/api/test", .GET);
    const ctx_admin = RequestContext.init("agent", "/admin/test", .GET);
    const ctx_other = RequestContext.init("agent", "/other", .GET);

    // Both methods should return same effect
    try std.testing.expectEqual(set.evaluate(&ctx_api), set.evaluateWithDecision(&ctx_api).effect);
    try std.testing.expectEqual(set.evaluate(&ctx_admin), set.evaluateWithDecision(&ctx_admin).effect);
    try std.testing.expectEqual(set.evaluate(&ctx_other), set.evaluateWithDecision(&ctx_other).effect);
}

// ============================================================================
// slow_match condition tests
// ============================================================================

test "Condition: slow_match always returns true after sleeping" {
    const ctx = RequestContext.init("agent", "/api/test", .GET);
    const condition = Condition{ .slow_match = 1 }; // 1ms sleep

    // Should return true after sleeping
    try std.testing.expect(condition.matches(&ctx));
}

test "Condition: slow_match with path condition (AND logic)" {
    const conditions = &[_]Condition{
        Condition{ .path = "/api/*" },
        Condition{ .slow_match = 1 },
    };
    const policy = Policy{
        .id = "slow-api",
        .effect = .allow,
        .conditions = conditions,
    };

    // Both conditions must match
    const ctx_match = RequestContext.init("agent", "/api/test", .GET);
    try std.testing.expect(policy.matchesAll(&ctx_match));

    // Path doesn't match - should return false (slow_match still sleeps)
    const ctx_no_match = RequestContext.init("agent", "/other", .GET);
    try std.testing.expect(!policy.matchesAll(&ctx_no_match));
}

test "PolicySet: evaluateWithTimeout returns decision within timeout" {
    const policies = &[_]Policy{
        Policy{
            .id = "allow-api",
            .effect = .allow,
            .conditions = &[_]Condition{Condition{ .path = "/api/*" }},
        },
    };
    const set = PolicySet{ .policies = policies };
    const ctx = RequestContext.init("agent", "/api/test", .GET);

    const decision = try set.evaluateWithTimeout(&ctx, 1000); // 1s timeout
    try std.testing.expectEqual(Effect.allow, decision.effect);
    try std.testing.expectEqualStrings("allow-api", decision.policy_id);
}

test "PolicySet: evaluateWithTimeout returns error.PolicyTimeout" {
    const policies = &[_]Policy{
        Policy{
            .id = "slow-deny",
            .effect = .deny,
            .conditions = &[_]Condition{
                Condition{ .path = "*" },
                Condition{ .slow_match = 50 }, // 50ms sleep
            },
        },
    };
    const set = PolicySet{ .policies = policies };
    const ctx = RequestContext.init("agent", "/api/test", .GET);

    // 1ms timeout should trigger before 50ms slow_match completes
    try std.testing.expectError(error.PolicyTimeout, set.evaluateWithTimeout(&ctx, 1));
}

test "PolicySet: evaluateWithTimeout default deny within timeout" {
    const policies = &[_]Policy{
        Policy{
            .id = "allow-specific",
            .effect = .allow,
            .conditions = &[_]Condition{Condition{ .path = "/specific/*" }},
        },
    };
    const set = PolicySet{ .policies = policies };
    const ctx = RequestContext.init("agent", "/other", .GET);

    const decision = try set.evaluateWithTimeout(&ctx, 1000);
    try std.testing.expectEqual(Effect.deny, decision.effect);
    try std.testing.expectEqualStrings("default-deny", decision.policy_id);
}

// ============================================================================
// AI Agent Tool Condition Tests
// ============================================================================

test "Condition: tool matches by name" {
    const ctx = RequestContext.initTool("agent", "bash", "ls -la", "");
    try std.testing.expect((Condition{ .tool = "bash" }).matches(&ctx));
    try std.testing.expect(!(Condition{ .tool = "read_file" }).matches(&ctx));
}

test "Condition: tool matches with empty tool_name" {
    const ctx = RequestContext.init("agent", "/api/test", .GET);
    // Standard context has empty tool_name, so tool condition should NOT match
    try std.testing.expect(!(Condition{ .tool = "bash" }).matches(&ctx));
}

test "Condition: tool_pattern matches with wildcard" {
    const ctx = RequestContext.initTool("agent", "read_file", "", "");
    try std.testing.expect((Condition{ .tool_pattern = "*" }).matches(&ctx));
    try std.testing.expect((Condition{ .tool_pattern = "read_*" }).matches(&ctx));
    try std.testing.expect((Condition{ .tool_pattern = "read_file" }).matches(&ctx));
    try std.testing.expect(!(Condition{ .tool_pattern = "write_*" }).matches(&ctx));
}

test "Condition: tool_pattern matches read prefix" {
    const ctx_read_file = RequestContext.initTool("agent", "read_file", "", "");
    const ctx_read = RequestContext.initTool("agent", "read", "", "");
    try std.testing.expect((Condition{ .tool_pattern = "read_*" }).matches(&ctx_read_file));
    // "read" does NOT start with "read_", so this should not match
    try std.testing.expect(!(Condition{ .tool_pattern = "read_*" }).matches(&ctx_read));
}

test "Condition: command_pattern blocks sensitive command" {
    const ctx = RequestContext.initTool("agent", "bash", "cat /etc/passwd", "");
    try std.testing.expect((Condition{ .command_pattern = "/etc/passwd" }).matches(&ctx));
    try std.testing.expect(!(Condition{ .command_pattern = "rm -rf" }).matches(&ctx));
}

test "Condition: command_pattern with empty command" {
    const ctx = RequestContext.initTool("agent", "bash", "", "");
    // Empty command should not match a non-empty pattern
    try std.testing.expect(!(Condition{ .command_pattern = "secret" }).matches(&ctx));
    // But empty pattern matches everything
    try std.testing.expect((Condition{ .command_pattern = "" }).matches(&ctx));
}

test "Condition: command_pattern wildcard matches everything" {
    const ctx = RequestContext.initTool("agent", "bash", "anything here", "");
    try std.testing.expect((Condition{ .command_pattern = "*" }).matches(&ctx));
}

test "Condition: command_pattern substring match" {
    const ctx = RequestContext.initTool("agent", "bash", "rm -rf /home/user", "");
    try std.testing.expect((Condition{ .command_pattern = "rm -rf" }).matches(&ctx));
    try std.testing.expect(!(Condition{ .command_pattern = "curl" }).matches(&ctx));
}

test "Condition: path_pattern allows workspace" {
    const ctx = RequestContext.initTool("agent", "read", "", "/workspace/src/main.zig");
    try std.testing.expect((Condition{ .path_pattern = "/workspace/*" }).matches(&ctx));
    try std.testing.expect(!(Condition{ .path_pattern = "/home/*" }).matches(&ctx));
}

test "Condition: path_pattern with prefix wildcard" {
    const ctx = RequestContext.initTool("agent", "read", "", "/workspace/src/main.zig");
    try std.testing.expect((Condition{ .path_pattern = "/workspace/*" }).matches(&ctx));
    try std.testing.expect((Condition{ .path_pattern = "/workspace/src/*" }).matches(&ctx));
    try std.testing.expect(!(Condition{ .path_pattern = "/etc/*" }).matches(&ctx));
}

test "Condition: path_pattern exact match" {
    const ctx = RequestContext.initTool("agent", "read", "", "/workspace/file.txt");
    try std.testing.expect((Condition{ .path_pattern = "/workspace/file.txt" }).matches(&ctx));
    try std.testing.expect(!(Condition{ .path_pattern = "/workspace/other.txt" }).matches(&ctx));
}

test "Condition: path_pattern empty path" {
    const ctx = RequestContext.initTool("agent", "bash", "ls", "");
    // Empty path with non-empty pattern should not match
    try std.testing.expect(!(Condition{ .path_pattern = "/workspace/*" }).matches(&ctx));
    // But empty/wildcard pattern should match
    try std.testing.expect((Condition{ .path_pattern = "" }).matches(&ctx));
    try std.testing.expect((Condition{ .path_pattern = "*" }).matches(&ctx));
}

test "Policy: with tool condition allows matching tool" {
    const conditions = &[_]Condition{
        Condition{ .tool = "bash" },
    };
    const policy = Policy{
        .id = "allow-bash",
        .effect = .allow,
        .conditions = conditions,
    };
    const ctx = RequestContext.initTool("agent", "bash", "ls", "");
    try std.testing.expect(policy.matchesAll(&ctx));
    // read_file should not match
    const ctx_read = RequestContext.initTool("agent", "read_file", "", "");
    try std.testing.expect(!policy.matchesAll(&ctx_read));
}

test "Policy: with tool + command_pattern denies dangerous command" {
    const conditions = &[_]Condition{
        Condition{ .tool = "bash" },
        Condition{ .command_pattern = "rm -rf" },
    };
    const policy = Policy{
        .id = "block-rm-rf",
        .effect = .deny,
        .conditions = conditions,
    };
    const ctx = RequestContext.initTool("agent", "bash", "rm -rf /", "");
    try std.testing.expect(policy.matchesAll(&ctx));

    // bash with safe command should not match
    const ctx_safe = RequestContext.initTool("agent", "bash", "ls -la", "");
    try std.testing.expect(!policy.matchesAll(&ctx_safe));

    // read_file with rm -rf in content should not match (wrong tool)
    const ctx_read = RequestContext.initTool("agent", "read_file", "rm -rf", "");
    try std.testing.expect(!policy.matchesAll(&ctx_read));
}

test "Policy: with path_pattern allows workspace access" {
    const conditions = &[_]Condition{
        Condition{ .tool_pattern = "read_*" },
        Condition{ .path_pattern = "/workspace/*" },
    };
    const policy = Policy{
        .id = "allow-read-workspace",
        .effect = .allow,
        .conditions = conditions,
    };

    // read_file on workspace path should be allowed
    const ctx_ok = RequestContext.initTool("agent", "read_file", "", "/workspace/src/main.zig");
    try std.testing.expect(policy.matchesAll(&ctx_ok));

    // read_file on /etc path should be denied
    const ctx_deny = RequestContext.initTool("agent", "read_file", "", "/etc/passwd");
    try std.testing.expect(!policy.matchesAll(&ctx_deny));

    // bash should not match (tool_pattern requires read_ prefix)
    const ctx_bash = RequestContext.initTool("agent", "bash", "ls", "/workspace");
    try std.testing.expect(!policy.matchesAll(&ctx_bash));
}

test "PolicySet: tool policies evaluated with first-match-wins" {
    const policies = &[_]Policy{
        Policy{
            .id = "allow-bash",
            .effect = .allow,
            .conditions = &[_]Condition{Condition{ .tool = "bash" }},
        },
        Policy{
            .id = "block-rm-rf",
            .effect = .deny,
            .conditions = &[_]Condition{
                Condition{ .tool = "bash" },
                Condition{ .command_pattern = "rm -rf" },
            },
        },
    };
    const set = PolicySet{ .policies = policies };

    // bash with rm -rf: allow-bash matches first (first-match-wins)
    const ctx_bash_rm = RequestContext.initTool("agent", "bash", "rm -rf /", "");
    try std.testing.expectEqual(Effect.allow, set.evaluate(&ctx_bash_rm));
}

test "PolicySet: reorder tool policies for correct precedence" {
    // block-rm-rf must come BEFORE allow-bash to take effect
    const policies = &[_]Policy{
        Policy{
            .id = "block-rm-rf",
            .effect = .deny,
            .conditions = &[_]Condition{
                Condition{ .tool = "bash" },
                Condition{ .command_pattern = "rm -rf" },
            },
        },
        Policy{
            .id = "allow-bash",
            .effect = .allow,
            .conditions = &[_]Condition{Condition{ .tool = "bash" }},
        },
    };
    const set = PolicySet{ .policies = policies };

    // bash with rm -rf: block-rm-rf matches first
    const ctx_bash_rm = RequestContext.initTool("agent", "bash", "rm -rf /", "");
    try std.testing.expectEqual(Effect.deny, set.evaluate(&ctx_bash_rm));

    // bash with safe command: falls through to allow-bash
    const ctx_bash_ls = RequestContext.initTool("agent", "bash", "ls -la", "");
    try std.testing.expectEqual(Effect.allow, set.evaluate(&ctx_bash_ls));
}

test "RequestContext: initTool sets tool fields correctly" {
    const ctx = RequestContext.initTool("agent-1", "read_file", "", "/workspace/file.txt");

    try std.testing.expectEqualStrings("agent-1", ctx.agent_id);
    try std.testing.expectEqualStrings("/workspace/file.txt", ctx.path);
    try std.testing.expectEqualStrings("read_file", ctx.tool_name);
    try std.testing.expectEqualStrings("", ctx.tool_command);
    try std.testing.expectEqualStrings("/workspace/file.txt", ctx.tool_path);
    try std.testing.expectEqual(Method.POST, ctx.method);
}

test "RequestContext: initTool with command sets all fields" {
    const ctx = RequestContext.initTool("agent-1", "bash", "cat /etc/passwd", "");

    try std.testing.expectEqualStrings("bash", ctx.tool_name);
    try std.testing.expectEqualStrings("cat /etc/passwd", ctx.tool_command);
    try std.testing.expectEqualStrings("", ctx.tool_path);
    // path should fall back to tool name when tool_path is empty
    try std.testing.expectEqualStrings("bash", ctx.path);
}

test "RequestContext: init preserves backward compatibility" {
    const ctx = RequestContext.init("agent-1", "/api/test", .GET);

    try std.testing.expectEqualStrings("agent-1", ctx.agent_id);
    try std.testing.expectEqualStrings("/api/test", ctx.path);
    try std.testing.expectEqual(Method.GET, ctx.method);
    // Tool fields should be empty by default
    try std.testing.expectEqualStrings("", ctx.tool_name);
    try std.testing.expectEqualStrings("", ctx.tool_command);
    try std.testing.expectEqualStrings("", ctx.tool_path);
}

test "Condition: tool conditions do not match standard context" {
    const ctx = RequestContext.init("agent", "/api/test", .GET);

    // Tool conditions should NOT match a standard (non-tool) context
    try std.testing.expect(!(Condition{ .tool = "bash" }).matches(&ctx));
    try std.testing.expect(!(Condition{ .command_pattern = "ls" }).matches(&ctx));
    try std.testing.expect(!(Condition{ .path_pattern = "/workspace/*" }).matches(&ctx));
}

test "Condition: standard conditions still match tool context" {
    const ctx = RequestContext.initTool("agent", "bash", "ls", "/workspace");

    // Standard conditions should still work with tool context
    try std.testing.expect((Condition{ .agent_id = "agent" }).matches(&ctx));
    try std.testing.expect((Condition{ .path = "/workspace" }).matches(&ctx));
    try std.testing.expect((Condition{ .method = .POST }).matches(&ctx));
}

test "Condition: path_pattern substring match" {
    const ctx = RequestContext.initTool("agent", "read", "", "/home/user/.env");
    // Substring match should find ".env" in the path
    try std.testing.expect((Condition{ .path_pattern = ".env" }).matches(&ctx));
    try std.testing.expect(!(Condition{ .path_pattern = ".ssh" }).matches(&ctx));
}